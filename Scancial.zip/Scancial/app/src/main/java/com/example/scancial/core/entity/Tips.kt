package com.example.scancial.core.entity

data class Tips(
    val name : String,
    val bgColor : String
)
